package fix;

import java.time.LocalDateTime;

import quickfix.*;
import quickfix.field.*;
import quickfix.Application;
import quickfix.ConfigError;
import quickfix.DefaultMessageFactory;
import quickfix.FileStoreFactory;
import quickfix.Message.*;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;
import quickfix.fix42.*;


public class InitiatorApp {

    public static void main(String[] args) throws ConfigError, InterruptedException, SessionNotFound {

        SessionSettings settings = new SessionSettings("src/test/resources/initiator.config");
        Application myApp = new FixInitiator();
        FileStoreFactory fileStoreFactory = new FileStoreFactory(settings);
        ScreenLogFactory screenLogFactory = new ScreenLogFactory(settings);
        DefaultMessageFactory msgFactory = new DefaultMessageFactory();
        SocketInitiator initiator = new SocketInitiator(myApp, fileStoreFactory, settings, screenLogFactory, msgFactory);
        initiator.start();
        SessionID sessionId = initiator.getSessions().get(0);

        Thread.sleep(3000);

        // matching values from sender.cfg
//        SessionID sessionID = new SessionID("FIX.4.4", "CLIENT1", "FixServer");
        quickfix.fix42.NewOrderSingle newOrder = new quickfix.fix42.NewOrderSingle();
        newOrder.setField(new ClOrdID("A001"));
        newOrder.setField(new Symbol("0001.HK"));
        newOrder.setField(new Side(Side.BUY));
        newOrder.setField(new OrdType(OrdType.LIMIT));
        newOrder.setField(new Price(68));
        newOrder.setField(new OrderQty(10000));
        newOrder.setField(new HandlInst('1'));
        newOrder.setField(new TransactTime(LocalDateTime.now()));
        Session.sendToTarget(newOrder, sessionId);

        Thread.sleep(60000);
        initiator.stop();
    }

//    public static void main(String[] args) {
//        SocketInitiator socketInitiator = null;
//        try {
//            SessionSettings sessionSettings = new SessionSettings("initiator.config");
//            Application application = new FixInitiator();
//            FileStoreFactory fileStoreFactory = new FileStoreFactory(sessionSettings);
//            FileLogFactory logFactory = new FileLogFactory(sessionSettings);
//            MessageFactory messageFactory = new DefaultMessageFactory();
//            socketInitiator = new SocketInitiator(application,
//                    fileStoreFactory, sessionSettings, logFactory,
//                    messageFactory);
//            socketInitiator.start();
//
//            /*** Logon ***/
//            SessionID sessionId = socketInitiator.getSessions().get(0);
//            Session session = Session.lookupSession(sessionId);
//            sendLogonRequest(sessionId);
//
//            int i = 0;
//            do {
//                try {
//                    Thread.sleep(1000);
//                    System.out.println(socketInitiator.isLoggedOn());
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                i++;
//            } while ((!socketInitiator.isLoggedOn()) && (i < 30));
//
//            sendOrderSingle(session);
//
//        } catch (ConfigError e) {
//            e.printStackTrace();
//        } catch (SessionNotFound e) {
//            e.printStackTrace();
//        } catch (Exception exp) {
//            exp.printStackTrace();
//        } finally {
//            if (socketInitiator != null) {
//                socketInitiator.stop(true);
//            }
//        }
//
//    }

//    public static void main(String[] args) throws SessionNotFound {
//        SocketInitiator socketInitiator = null;
//        try {
//            SessionSettings initiatorSettings = new SessionSettings(
//                    "initiator.config");
//            Application initiatorApplication = new FixInitiator();
//            FileStoreFactory fileStoreFactory = new FileStoreFactory(
//                    initiatorSettings);
//            FileLogFactory fileLogFactory = new FileLogFactory(
//                    initiatorSettings);
//            MessageFactory messageFactory = new DefaultMessageFactory();
//            socketInitiator = new SocketInitiator(initiatorApplication, fileStoreFactory, initiatorSettings, fileLogFactory, messageFactory);
//            socketInitiator.start();
//            SessionID sessionId = socketInitiator.getSessions().get(0);
//            Session session = Session.lookupSession(sessionId);
//            try {
//                session.setNextSenderMsgSeqNum(1);
//                session.setNextTargetMsgSeqNum(1);
//            } catch (Exception e) {
//            }
//            session.logon();
//            session.generateHeartbeat();
//            //session.send(new quickfix.fix42.Logon());
//
//            /* Test */
//            sendOrderSingle(session);
//        } catch (ConfigError e) {
//            e.printStackTrace();
//        }
//    }

    private static void sendLogonRequest(SessionID sessionId) throws SessionNotFound {
        Logon logon = new Logon();
        Header header = logon.getHeader();
        header.setField(new BeginString("FIX.4.2"));
        logon.set(new HeartBtInt(10));
        logon.set(new ResetSeqNumFlag(true));
        boolean sent = Session.sendToTarget(logon, sessionId);
        System.out.println("Logon Message Sent : " + sent);
    }

    private static void sendOrderSingle(Session s) {
        quickfix.fix42.NewOrderSingle newOrder = new quickfix.fix42.NewOrderSingle();
        newOrder.setField(new ClOrdID("AAAA0001"));
        newOrder.setField(new Symbol("0001.HK"));
        newOrder.setField(new Side(Side.BUY));
        newOrder.setField(new OrdType(OrdType.LIMIT));
        newOrder.setField(new Price(68));
        newOrder.setField(new OrderQty(10000));
        System.out.println("testing1");
        System.out.println(newOrder.toString());
        System.out.println(s.isLoggedOn());
        s.send(newOrder);
        System.out.println("testing2");
    }
}