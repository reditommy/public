package stepdefs;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import org.apache.http.client.utils.URIBuilder;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;

import java.io.File;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.openqa.selenium.winium.WiniumDriverService;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Variant;
import com.jacob.com.Dispatch;

import java.util.List;


public class WiniumStepDef {

    private WiniumDriver driver;
    private URIBuilder uri;

    @Given("^I open \"(.+)\"$")
    public void load(String key) throws Throwable {
        //Runtime.getRuntime().exec("Winium.Desktop.Driver.exe");
        DesktopOptions option = new DesktopOptions();
        option.setDebugConnectToRunningApp(true);
        option.setApplicationPath("C:\\Windows\\System32\\calc.exe");
        //driver = new WiniumDriver(new URL("http://localhost:9999"), option);

        String winiumDriverPath = "Winium.Desktop.Driver.exe";
        File drivePath = new File(winiumDriverPath);
        WiniumDriverService service = new WiniumDriverService.Builder().usingDriverExecutable(drivePath).usingPort(9999).withVerbose(true).withSilent(false).buildDesktopService();
        Thread.sleep(1000);
        service.start(); //Build and Start a Winium Driver service
        driver = new WiniumDriver(service, option); //Start a winium driver
        Thread.sleep(1000);
    }


    @When("^I test \"(.+)\"$")
    public void test(String key) throws Throwable {
        driver.findElementByName(key).click();
        Thread.sleep(1000);
        String output = driver.findElementByName(key).getAttribute("Name");
        System.out.println("Result after addition is: " + output);
    }

    @When("^I test word$")
    public void testWord() throws Throwable {
        String strDir = "C:\\Users\\leuntom\\Downloads\\test";
        String strInputDoc = strDir + ".docx";
        String strOutputDoc = strDir + "file_out.doc";
        String strOldText = "Testing1";
        String strNewText = "Testing2";
        boolean isVisible = true;
        boolean isSaveOnExit = true;

        ActiveXComponent oWord = new ActiveXComponent("Word.Application");
        oWord.setProperty("Visible", new Variant(isVisible));
        Dispatch oDocuments = oWord.getProperty("Documents").toDispatch();
        Dispatch oDocument = Dispatch.call(oDocuments, "Open", strInputDoc).toDispatch();
        Dispatch oSelection = oWord.getProperty("Selection").toDispatch();
        Dispatch oFind = oWord.call(oSelection, "Find").toDispatch();
        Dispatch.put(oFind, "Text", strOldText);
        Dispatch.call(oFind, "Execute");
        Dispatch.put(oSelection, "Text", strNewText);
        Dispatch.call(oSelection, "MoveDown");
        Dispatch.put(oSelection, "Text", "nSo we got the next line including BR.n");

        Dispatch oFont = Dispatch.get(oSelection, "Font").toDispatch();
        Dispatch.put(oFont, "Bold", "1");
        Dispatch.put(oFont, "Italic", "1");
        Dispatch.put(oFont, "Underline", "0");

        Dispatch oAlign = Dispatch.get(oSelection, "ParagraphFormat").
                toDispatch();
        Dispatch.put(oAlign, "Alignment", "3");
        Dispatch oWordBasic = (Dispatch) Dispatch.call(oWord, "WordBasic").
                getDispatch();
        Dispatch.call(oWordBasic, "FileSaveAs", strOutputDoc);
        Dispatch.call(oDocument, "Close", new Variant(isSaveOnExit));
        oWord.invoke("Quit", new Variant[0]);
    }

    @When("^I test cal$")
    public void testCal(String key) throws Throwable {
        driver.findElement(By.name("7")).click();
        driver.findElement(By.name("Add")).click();
        driver.findElement(By.name("8")).click();
        driver.findElement(By.name("Equals")).click();

        Thread.sleep(1000);
        String output = driver.findElement(By.id("CalculatorResults")).getAttribute("Name");
        System.out.println("Result after addition is: " + output);
    }


    @After
    public void tearDown() {
        driver.quit();
    }

}