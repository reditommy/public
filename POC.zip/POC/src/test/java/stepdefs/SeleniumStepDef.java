package stepdefs;

import cucumber.api.java.After;
import cucumber.api.java.en.*;
import org.apache.http.client.utils.URIBuilder;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;


public class SeleniumStepDef {

    private WebDriver driver;
    private URIBuilder uri;

    @Given("^I load the Top Rated Movies page$")
    public void load() throws Throwable {

        System.setProperty("webdriver.gecko.driver", "geckodriver.exe");

        // Create a new instance of browser
        driver = new ChromeDriver();

        //Launch the IMDB Website
        uri = new URIBuilder("http://www.imdb.com/chart/top");
        driver.get(uri.toString());

    }

    @Given("^I refine by Genre \"(.+)\"$")
    public void filter(String filter) throws Throwable {
        //filter by Genre
        uri = new URIBuilder("http://www.imdb.com/search/title");
        uri.addParameter("genres", filter);
        driver.get(uri.toString());
    }

    @Given("^I sort the list by \"(.+)\"$")
    public void sort(String key) throws Throwable {
        //sort by release day
        uri = new URIBuilder(driver.getCurrentUrl());
        uri.addParameter("sort", "us");
        driver.get(uri.toString());
    }

    @Then("^the list of movies should only contain relevant results$")
    public void verifyFilter() throws Throwable {
        List<WebElement> element = driver.findElements(By.className("genre"));
        for (int i = 0; i < element.size(); i++) {
            System.out.println("Verifing " + (i + 1) + "th movie");
            Assert.assertThat(element.get(i).getText(), CoreMatchers.containsString("Comedy"));
        }
    }

    @Then("^the list of movies should be displayed in order of release date$")
    public void verifySorting() throws Throwable {
        List<WebElement> element = driver.findElements(By.className("secondaryInfo"));
        for (int i = 1; i < element.size(); i++) {
            System.out.println("Verifing " + (i + 1) + "th movie");
            Assert.assertTrue(Integer.parseInt(element.get(i).getText().replaceAll("[^\\d.]", "")) <= (Integer.parseInt(element.get(i - 1).getText().replaceAll("[^\\d.]", ""))));
        }
    }

    @After
    public void tearDown() {
        //driver.quit();
    }

}