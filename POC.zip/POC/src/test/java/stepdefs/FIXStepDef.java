package stepdefs;

import cucumber.api.java.en.*;
import cucumber.api.DataTable;
import cucumber.api.java.After;

import java.util.List;
import java.util.Map;

import java.time.LocalDateTime;

import fix.*;
import org.junit.Assert;
import quickfix.*;
import quickfix.field.*;
import quickfix.DefaultMessageFactory;
import quickfix.FileStoreFactory;
import quickfix.Message;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;

public class FIXStepDef {
    private static FixInitiator myApp = new FixInitiator();
    private static SocketInitiator initiator;
    private static SessionID sessionId;

    @Given("^I am connected to FIX Session \"(.+)\"$")
    public void connect1(String compID) throws Throwable {
        String[] compIDs = compID.split("<>", 2);
        String senderCompID = compIDs[0];
        String targetCompID = compIDs[1];

        SessionSettings settings = new SessionSettings("src/test/resources/config/initiator.config");
        settings.setString("SenderCompID", senderCompID);
        settings.setString("TargetCompID", targetCompID);
        FileStoreFactory fileStoreFactory = new FileStoreFactory(settings);
        ScreenLogFactory screenLogFactory = new ScreenLogFactory(settings);
        DefaultMessageFactory msgFactory = new DefaultMessageFactory();
        initiator = new SocketInitiator(myApp, fileStoreFactory, settings, screenLogFactory, msgFactory);
        initiator.start();
        Thread.sleep(2000);
    }


    @Given("^I am connected to FIX Session \"(.+)\" \\((.*)\\)$")
    public void connect1(String compID, String target) throws Throwable {
        String[] compIDs = compID.split("<>", 2);
        String senderCompID = compIDs[0];
        String targetCompID = compIDs[1];
        String[] targets = target.split(":", 2);
        String host = targets[0];
        long port = Long.parseLong(targets[1]);

        SessionSettings settings = new SessionSettings("src/test/resources/config/initiator.config");
        FileStoreFactory fileStoreFactory = new FileStoreFactory(settings);

        // override the session connection details
        settings.setString("SenderCompID", senderCompID);
        settings.setString("TargetCompID", targetCompID);
        settings.setString(quickfix.Initiator.SETTING_SOCKET_CONNECT_HOST, host);
        settings.setLong(quickfix.Initiator.SETTING_SOCKET_CONNECT_PORT, port);
        settings.setLong(quickfix.Session.SETTING_HEARTBTINT, 30);
        settings.setString(SessionSettings.BEGINSTRING, "FIX.4.2");
        settings.setString("DataDictionary", "FIX42.xml");
        settings.setString("ResetOnLogon", "Y");
        settings.setString("FileStorePath", "storage/messages/");
        settings.setString("FileLogPath", "log/");

        ScreenLogFactory screenLogFactory = new ScreenLogFactory(settings);
        DefaultMessageFactory msgFactory = new DefaultMessageFactory();
        initiator = new SocketInitiator(myApp, fileStoreFactory, settings, screenLogFactory, msgFactory);
        initiator.start();
        Thread.sleep(2000);
    }


    @When("^I send an order with$")
    public void sendOrder(DataTable table) throws Throwable {
        List<Map<String, String>> list = table.asMaps(String.class, String.class);
        SessionID sessionId = initiator.getSessions().get(0);

        Side side = new Side(Side.BUY);
        switch (list.get(0).get("Side")) {
            case "BUY":
                side = new Side(Side.BUY);
                break;
            case "SELL":
                side = new Side(Side.SELL);
                break;
        }
        OrdType ordType = new OrdType(OrdType.MARKET);
        switch (list.get(0).get("OrdType")) {
            case "LIMIT":
                ordType = new OrdType(OrdType.LIMIT);
                break;
            case "Market":
                ordType = new OrdType(OrdType.MARKET);
                break;
        }

        quickfix.fix42.NewOrderSingle newOrder = new quickfix.fix42.NewOrderSingle();
        newOrder.setField(new ClOrdID(list.get(0).get("ClOrdID")));
        newOrder.setField(new Symbol(list.get(0).get("Symbol")));
        newOrder.setField(side);
        newOrder.setField(ordType);
        newOrder.setField(new Price(Float.parseFloat(list.get(0).get("Price"))));
        newOrder.setField(new OrderQty(Integer.parseInt(list.get(0).get("OrderQty"))));
        newOrder.setField(new HandlInst(list.get(0).get("HandlInst").charAt(0)));
        newOrder.setField(new TransactTime(LocalDateTime.now()));
        Session.sendToTarget(newOrder, sessionId);
    }


    @Then("^the order is (Accepted|Rejected)$")
    public void verifyAck(String result) throws Throwable {
//        myApp.getAckLatch().await(30, TimeUnit.SECONDS);
        Message ack = myApp.getAck();
        if (result.equals("Accepted") && ack.getField(new ExecType()).valueEquals('0')) {
            System.out.println("Accepted --> " + ack.toString());
        } else if (result.equals("Rejected") && ack.getField(new ExecType()).valueEquals('8')) {
            System.out.println("Rejected --> " + ack.toString());
        } else {
            Assert.fail("Expected (" + result + ") but Actual Message = " + ack.toString());
        }
    }


    @After
    public void tearDown() {
        initiator.stop();
    }

}